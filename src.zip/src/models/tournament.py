class Tournament():
    def __init__(self, name, location, date_start, date_end, rounds, players, time_control, description):
        self.name = name
        self.location = location
        self.date_start = date_start
        self.date_end = date_end
        self.rounds = rounds
        self.players = players
        self.time_control = time_control
        self.description = description
        
    def get_name(self):
        return __name__
        
     