class TournamentController :
    def __init__(self):
        pass
    
    #recojo los paramtros 
    @classmethod
    def create_a_tournament(self, Tournament,location,date_start,date_end,rounds,players,time_control,description):
        pass
        